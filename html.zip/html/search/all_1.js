var searchData=
[
  ['ema_5ffilter_0',['ema_filter',['../main_8py.html#a88f1666834bba82667cea2254764215d',1,'main']]]
];
