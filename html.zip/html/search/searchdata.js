var indexSectionsWithContent =
{
  0: "aemps",
  1: "m",
  2: "ep",
  3: "as"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables"
};

