var searchData=
[
  ['pid_5fcontrolx_0',['pid_controlx',['../main_8py.html#a8f8879e6c92e3a035e2f74b08e08b33f',1,'main']]],
  ['pid_5fcontroly_1',['pid_controly',['../main_8py.html#a25d9c09f93291a315b19a8e8c39ff5ca',1,'main']]]
];
